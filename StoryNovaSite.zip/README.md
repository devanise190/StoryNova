# StoryNova
A short story publishing platform with coins and premium content.